<?php
include 'databaseDB.php'; //include database connecttion file

//read the raw post data and decode it from JSON into PHP
$data = json_decode(file_get_contents("php://input"));
$checklistId = $_GET['checklistId'] ?? '';

//Prepare SQL statement
$sql = "SELECT id, checklistsId, checklistDesc, status, dateCreated, timeCreated 
        FROM checklistsitems 
        WHERE checklistsId ='". mysqli_real_escape_string($conn, $checklistId) ."'";
$result = mysqli_query($conn, $sql);
$items = [];

//check if result is true
while ($row = mysqli_fetch_assoc($result)){
    $items[] = $row;
}

if(!empty($items)){
    echo json_encode([
        'success' => true,
        'items' => $items
    ]);
}else{
    echo json_encode([
        'success' => false,
        'items' => []
    ]);
}

//close database connection
$conn->close();
?>