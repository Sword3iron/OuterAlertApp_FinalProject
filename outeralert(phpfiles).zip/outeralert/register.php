<?php
include 'databaseDB.php'; //include database connecttion file

//read the raw post data and decode it from JSON into PHP
$data = json_decode(file_get_contents("php://input"));
$username = $data -> username;
$email = $data -> email;
$password = password_hash($data->password, PASSWORD_DEFAULT);
$contactNumber = $data-> contactNumber;
$profilePicBase64 = $data-> profilePic;
$filename = null;

//profile picture encoding 
if($profilePicBase64){
    $filename = uniqid() . ".jpg";
    $filepath = "picupload/" . $filename;
    file_put_contents($filepath, base64_decode($profilePicBase64));
}

//Prepare SQL statement
$sql = "INSERT INTO users (username, email, password, contactNumber, profilePic) 
        VALUES 
        ('$username', '$email', '$password', '$contactNumber', '$filename')";

//check if result is true
if ($conn->query($sql) === TRUE)
{
    echo json_encode(["success" => true]);
}else{
    echo json_encode(["success" => false,
                      "error" => $conn -> error]);
}

//close database connection
$conn -> close();
?>