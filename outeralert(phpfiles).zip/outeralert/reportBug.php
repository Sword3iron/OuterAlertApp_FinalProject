<?php
include 'databaseDB.php'; //include database connecttion file

//read the raw post data and decode it from JSON into PHP
$data = json_decode(file_get_contents("php://input"));
$bugsType = $data->bugsType;
$bugsDesc = $data->bugsDesc;

//Prepare SQL statement
$sql = "INSERT INTO bugs (bugsType, bugsDesc) 
        VALUES 
        ('$bugsType', '$bugsDesc')";

//check if result is true
if ($conn->query($sql) === TRUE)
{
    echo json_encode(["success" => true]);
}else{
    echo json_encode(["success" => false,
                      "error" => $conn -> error]);
}

//close database connection
$conn -> close();
?>