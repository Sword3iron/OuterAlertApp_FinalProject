<?php
include 'databaseDB.php'; //include database connecttion file

//read the raw post data and decode it from JSON into PHP
$data = json_decode(file_get_contents("php://input"));

//Prepare SQL statement
$sql = "SELECT id, articleTitle, articleSub, articleImage
        FROM articles
        ORDER BY created_at DESC";
$result = $conn->query($sql);

//check if result is true
if($result && $result -> num_rows > 0)
{
    $articles = [];
    while($row = $result->fetch_assoc()){
        $articles[] = $row;
    }
    echo json_encode([
        "success" => true,
        "articles" => $articles
    ]);
}else{
    echo json_encode([
        "success" => false,
        "message" => "No articles found"
    ]);
}

//close database connection
$conn->close();
?>