<?php
include 'databaseDB.php'; //include database connecttion file

//read the raw post data and decode it from JSON into PHP
$data = json_decode(file_get_contents("php://input"));
$currentUsername = $data->currentUsername;
$username = $data -> username;
$profilePicBase64 = $data-> profilePic;
$filename = null;

//profile picture encoding 
if($profilePicBase64){
    $filename = uniqid() . ".jpg";
    $filepath = "picupload/" . $filename;
    file_put_contents($filepath, base64_decode($profilePicBase64));
}

//update username and profile picture
$setParts = ["username = '$username'"];
if($filename){
    $setParts[] = "profilePic = '$filename'";
}
$setClause = implode(", ", $setParts); //Set the clause of sql to set the id accordance to user

//Prepare SQL statement
$sql = "UPDATE users SET $setClause WHERE username = '$currentUsername'";

//check if result is true
if ($conn->query($sql) === TRUE)
{
    echo json_encode(["success" => true,
                      "profilePic" => $filename]);
}else{
    echo json_encode(["success" => false,
                      "error" => $conn -> error]);
}

//close database connection
$conn->close();
?>