<?php
include 'databaseDB.php'; //include database connecttion file

//read the raw post data and decode it from JSON into PHP
$data = json_decode(file_get_contents("php://input"));
$id = intval($_GET['id']);

//Prepare SQL statement
$sql = "SELECT id, articleTitle, articleSub, articleImage, articleContent, created_at 
        FROM articles
        WHERE id = $id";
$result = $conn->query($sql);

//check if result is true
if($result && $result -> num_rows > 0)
{
    $article = $result -> fetch_assoc();
    echo json_encode([
        "success" => true,
        "article" => $article   
    ]);
}else{
    echo json_encode([
        "success" => false,
        "message" => "No articles found"
    ]);
}

//close database connection
$conn->close();
?>