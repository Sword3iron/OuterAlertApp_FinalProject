<?php
include 'databaseDB.php'; //include database connecttion file

//read the raw post data and decode it from JSON into PHP
$data = json_decode(file_get_contents("php://input"));
$email = $data->email;

//Prepare SQL statement
$sql = "SELECT * FROM users WHERE email = '$email'";
$result = $conn->query($sql);

//check if result is true
if($result -> num_rows > 0)
{
    $user = $result -> fetch_assoc();
    echo json_encode(["success" => true,
                      "user" => $user]);
}else{
    echo json_encode(["success" => false,
                      "message" => "user not found"]);
}

//close database connection
$conn->close();
?>