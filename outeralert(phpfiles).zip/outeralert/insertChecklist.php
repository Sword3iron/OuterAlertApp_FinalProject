<?php
include 'databaseDB.php'; //include database connecttion file

//read the raw post data and decode it from JSON into PHP
$data = json_decode(file_get_contents("php://input"));
$userId = $data->userId;
$checklistTitle = mysqli_real_escape_string($conn, $data->checklistTitle);
$taskItems = $data->taskItems;

//Prepare SQL statement
$sqlChecklist = "INSERT INTO checklists (userId, checklistTitle, dateCreated, timeCreated) 
        VALUES
        ('$userId', '$checklistTitle' , CURDATE(), CURTIME())";

//check if result is true
if(mysqli_query($conn, $sqlChecklist)){
    $checklistId = mysqli_insert_id($conn);

    foreach($taskItems as $task){
        $taskDesc = mysqli_real_escape_string($conn, $task);
        $sqlItem = "INSERT INTO checklistsitems(checklistsId, checklistDesc, status, dateCreated, timeCreated)
                    VALUES
                    ('$checklistId', '$taskDesc', 'not_done', CURDATE(), CURTIME())";
        mysqli_query($conn, $sqlItem);
    }
    echo json_encode(['success' => true,
                      'message' => "Checklist added!"]);
}else{
    echo json_encode(['success' => false,
                      'message' => 'Failed to add into checklist']);
}

//close database connection
$conn->close();
?>