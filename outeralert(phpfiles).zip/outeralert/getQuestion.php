<?php
include 'databaseDB.php'; //include database connecttion file

//read the raw post data and decode it from JSON into PHP
$data = json_decode(file_get_contents("php://input"));
$topic = $_GET['topic'] ? $_GET['topic'] : '';
$topic = mysqli_real_escape_string($conn, $topic);

//Prepare SQL statement
$sql = "SELECT * FROM questions WHERE topic = '$topic' LIMIT 10";
$result = $conn->query($sql);

//check if result is true
if($result -> num_rows > 0)
{
    $questions = [];
    while($row = $result->fetch_assoc()){
        $questions[] = $row;
    }
    echo json_encode([
        "success" => true,
        "questions" => $questions
    ]);
}else{
    echo json_encode([
        "success" => false,
        "message" => "Questions Not Found"
    ]);
}

//close database connection
$conn->close();
?>