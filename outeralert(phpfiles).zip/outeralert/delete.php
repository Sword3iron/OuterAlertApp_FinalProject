<?php
include 'databaseDB.php'; //include database connecttion file

//read the raw post data and decode it from JSON into PHP
$data = json_decode(file_get_contents("php://input")); 
$username = $data->username ?? '';
$username = trim($username);

//Prepare SQL statement
$selectSql = "SELECT profilePic FROM users WHERE username = '$username'";
$result = $conn->query($selectSql);
$profilePic = null;

//check if result is true
if($result && $result -> num_rows > 0)
{
    $row = $result->fetch_assoc();
    $profilePic = $row['profilePic'];
}

$deleteSql = "DELETE FROM users WHERE username = '$username'";
if($conn->query($deleteSql) === TRUE)
{
    if($profilePic && file_exists("picupload/$profilePic"))
    {
        unlink("picupload/$profilePic");
    }
    echo json_encode(['success' => true, "message" => "User Deleted"]);
}else{
    echo json_encode(['success' => false, "error" => $conn->error]);
}

//close database connection
$conn->close();
?>