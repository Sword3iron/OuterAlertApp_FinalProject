<?php
include 'databaseDB.php'; //include database connecttion file

//Read the raw POST data and decode JSON into an associative array
$data = json_decode(file_get_contents("php://input"), true);

//Validate the received data
$userId = isset($data['userId']) ? intval($data['userId']) : 0;
$earnedXP = isset($data['earnedXP']) ? intval($data['earnedXP']) : -1;

//check for invalid ata
if($userId <= 0 || $earnedXP < 0){
    echo json_encode(['success' => false,
                      'message' => "Invalid Data"]);
                      exit;
}

//Query the database to get current XP and level of the user
$res = $conn->query("SELECT xp, level FROM users WHERE id = $userId LIMIT 1");
if (!$res || $res->num_rows === 0){
    echo json_encode(['success' => false,
                      'message' => 'User not found']);
                      exit;
}

//fetch the user's current XP and level
$row = $res->fetch_assoc();
$currentXP = $row['xp'];
$currentLevel = $row['level'];
$newXP = $currentXP + $earnedXP;

//handle level up
//for each 1000XP, increment level and deduct 1000XP
while($newXP >= 1000){
    $newXP -= 1000; //substract 1000 XP for level up
    $currentLevel++; //increment level
}

//Prepare SQL statement
$update = $conn->query("UPDATE users SET xp = $newXP, level = $currentLevel WHERE id = $userId");

//check if result is true
if($update){
    echo json_encode([
        "success" => true,
        "xp" => $newXP,
        "level" => $currentLevel
    ]);
}else{
    echo json_encode(['success' => false,
                      'message' => 'Update Failed']);
}

//close database connection
$conn->close();
?>