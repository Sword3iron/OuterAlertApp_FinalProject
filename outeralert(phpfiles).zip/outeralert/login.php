<?php
include 'databaseDB.php'; //include database connecttion file

//read the raw post data and decode it from JSON into PHP
$data = json_decode(file_get_contents("php://input"));
$email = $data->email;
$password = $data->password;

//Prepare SQL statement
$sql = "SELECT * FROM users WHERE email = '$email'";
$result = $conn->query($sql);

//check if result is true
if ($result->num_rows > 0)
{
    $user = $result->fetch_assoc();
    if(password_verify($password, $user['password']))
    {
        echo json_encode(['success' => true,
        "id" => $user['id'],
        "username" => $user['username'],
        "profilePic" => $user['profilePic'],
        "level" => $user['level']
    ]);
    }else{
        echo  json_encode([
            "success" => false,
            "message" => "Invalid Password",
            "debug_password" => $password,
            "debug_hash" => $user['password']
        ]);
    }
}else{
    echo json_encode(["success" => false, "message" => "User not found in database."]);
}

//close database connection
$conn -> close();
?>