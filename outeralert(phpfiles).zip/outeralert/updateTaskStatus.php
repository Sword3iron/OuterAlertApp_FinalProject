<?php
include 'databaseDB.php'; //include database connecttion file

//read the raw post data and decode it from JSON into PHP
$data = json_decode(file_get_contents("php://input"));
$id = isset($data->id) ? intval($data->id) : 0;
$status = isset($data->status) ? mysqli_real_escape_string($conn, $data->status) : '';

//check if result is true
if ($id > 0 && $status !== ''){
    //Prepare SQL statement
    $sql = "UPDATE checklistsitems SET status = '$status' WHERE id = $id";

    if(mysqli_query($conn, $sql)){
        echo json_encode(['success' => true]);
    }else{
        echo json_encode([
                        'success' => false,
                        'message' => "Database update failed"
        ]);
    }
}else{
    echo json_encode([
        'success' => false,
        'message' => "Invalid ID or status"
    ]);
}

//close database connection
$conn->close();
?>