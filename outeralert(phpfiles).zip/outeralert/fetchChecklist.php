<?php
include 'databaseDB.php'; //include database connecttion file

//read the raw post data and decode it from JSON into PHP
$data = json_decode(file_get_contents("php://input"));
$userId = $_GET['userId'];

//Prepare SQL statement
$sql = "SELECT id, checklistTitle, dateCreated, timeCreated 
        FROM checklists 
        WHERE userId='". mysqli_real_escape_string($conn, $userId) ."' 
        ORDER BY id DESC";
$result = mysqli_query($conn, $sql);
$checklists = [];

//check if result is true
while ($row = mysqli_fetch_assoc($result)){
    $checklists[] = $row;
}

if(!empty($checklists)){
    echo json_encode([
        'success' => true,
        'checklists' => $checklists
    ]);
}else{
    echo json_encode([
        'success' => false,
        'checklists' => []
    ]);
}

//close database connection
$conn->close();
?>