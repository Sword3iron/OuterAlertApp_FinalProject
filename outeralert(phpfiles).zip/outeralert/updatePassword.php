<?php
include 'databaseDB.php'; //include database connecttion file

//read the raw post data and decode it from JSON into PHP
$data = json_decode(file_get_contents("php://input"));
$username = $data->username;
$newPassword = password_hash($data->password, PASSWORD_DEFAULT);

//Prepare SQL statement
$sql = "UPDATE users SET password = '$newPassword' WHERE username = '$username'";

//check if result is true
if ($conn->query($sql) === TRUE)
{
    echo json_encode(["success" => true]);
}else{
    echo json_encode(["success" => false,
                      "error" => $conn -> error]);
}

//close database connection
$conn->close();
?>