<?php
include 'databaseDB.php'; //include database connecttion file

//read the raw post data and decode it from JSON into PHP
$data = json_decode(file_get_contents("php://input"));
$usedFrequent = $data->usedFrequent;
$usedFeature = $data->usedFeature;
$usedDislike = $data->usedDislike;
$usedImprovement = $data->usedImprovement;
$usedRating = $data->usedRating;

//Prepare SQL statement
$sql = "INSERT INTO feedback (usedFrequent, usedFeature, usedDislike, usedImprovement, usedRating) 
        VALUES 
        ('$usedFrequent', '$usedFeature', '$usedDislike', '$usedImprovement', '$usedRating')";

//check if result is true
if ($conn->query($sql) === TRUE)
{
    echo json_encode(["success" => true]);
}else{
    echo json_encode(["success" => false,
                      "error" => $conn -> error]);
}

//close database connection
$conn -> close();
?>